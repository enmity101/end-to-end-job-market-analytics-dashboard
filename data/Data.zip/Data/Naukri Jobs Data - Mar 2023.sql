## 1. Database Setup

```sql
-- Create a dedicated database for the job market project
CREATE DATABASE job_market;

-- Use the database
USE job_market;
```

---

## 2. Raw Table Creation (CSV-compatible schema)

```sql
-- Create raw jobs table
-- All columns are kept as TEXT to avoid CSV import failures
-- Data cleaning and type conversion will be handled later in Power BI
CREATE TABLE jobs_raw (
    Title TEXT,
    Company TEXT,
    starRating TEXT,
    reviewsCount TEXT,
    experience TEXT,
    salary TEXT,
    location TEXT,
    job_description TEXT,
    skill_1 TEXT,
    skill_2 TEXT,
    skill_3 TEXT,
    skill_4 TEXT,
    skill_5 TEXT,
    skill_6 TEXT,
    skill_7 TEXT,
    skill_8 TEXT,
    posted_on TEXT,
    Dept TEXT
);
```

---

## 3. Data Validation Queries

```sql
-- Check total number of records imported
SELECT COUNT(*) AS total_jobs
FROM jobs_raw;
```

```sql
-- Validate relevant analytical scope
-- Counts jobs related to Data & Analyst roles
SELECT COUNT(*) AS data_analyst_jobs
FROM jobs_raw
WHERE Title LIKE '%Data%'
   OR Title LIKE '%Analyst%';
```

---

## 4. Skill Unpivoting (Core Transformation)

### Why this is needed

* Skills are stored across multiple columns (skill_1 → skill_8)
* This structure is not analyzable
* We convert it into a **long format** (one skill per row)

```sql
-- Create a long-format skill table
-- Each row represents one job-skill relationship
CREATE TABLE jobs_skills AS

SELECT Title, Dept, skill_1 AS skill
FROM jobs_raw
WHERE skill_1 IS NOT NULL

UNION ALL
SELECT Title, Dept, skill_2
FROM jobs_raw
WHERE skill_2 IS NOT NULL

UNION ALL
SELECT Title, Dept, skill_3
FROM jobs_raw
WHERE skill_3 IS NOT NULL

UNION ALL
SELECT Title, Dept, skill_4
FROM jobs_raw
WHERE skill_4 IS NOT NULL

UNION ALL
SELECT Title, Dept, skill_5
FROM jobs_raw
WHERE skill_5 IS NOT NULL

UNION ALL
SELECT Title, Dept, skill_6
FROM jobs_raw
WHERE skill_6 IS NOT NULL

UNION ALL
SELECT Title, Dept, skill_7
FROM jobs_raw
WHERE skill_7 IS NOT NULL

UNION ALL
SELECT Title, Dept, skill_8
FROM jobs_raw
WHERE skill_8 IS NOT NULL;
```

---

## 5. Validate Unpivot Results

```sql
-- Confirm row expansion after unpivot
-- Row count should be significantly higher than jobs_raw
SELECT COUNT(*) AS total_skill_rows
FROM jobs_skills;
```

```sql
-- Identify most in-demand skills
SELECT skill, COUNT(*) AS demand_count
FROM jobs_skills
GROUP BY skill
ORDER BY demand_count DESC
LIMIT 10;
```

---

## 6. Skill Normalization (SQL-level grouping example)

```sql
-- Normalize SQL-related skills into a single category
-- This prevents fragmented skill counts (MYSQL, POSTGRESQL, etc.)
SELECT
    Title,
    Dept,
    CASE
        WHEN skill LIKE '%SQL%' THEN 'SQL'
        ELSE skill
    END AS sql_grouped
FROM jobs_skills;
```

*(Final normalization is typically completed in Power Query for flexibility.)*

---

## 7. Export Queries (Optional – Server-side)

```sql
-- Export raw jobs data to CSV (server-side export)
SELECT *
FROM jobs_raw
INTO OUTFILE '/var/lib/mysql-files/jobs_raw.csv'
FIELDS TERMINATED BY ','
ENCLOSED BY '"'
LINES TERMINATED BY '\n';
```

```sql
-- Export unpivoted skills data
SELECT *
FROM jobs_skills
INTO OUTFILE '/var/lib/mysql-files/jobs_skills.csv'
FIELDS TERMINATED BY ','
ENCLOSED BY '"'
LINES TERMINATED BY '\n';
```

---

## 8. Why this SQL matters (portfolio value)

* Demonstrates **real-world data preparation**
* Shows understanding of **data grain**
* Avoids many-to-many modeling errors
* Separates **structural SQL work** from **analytical Power BI work**
* Mirrors how analysts actually work in production


